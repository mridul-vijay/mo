#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct PasswordEntry {
    string owner;
    string website;
    string username;
    string encryptedPassword;
};

const string USERS_FILE = "users.txt";
const string VAULT_FILE = "vault.txt";

string currentUsername;
string currentVaultKey;

string toHexNumber(unsigned long long value) {
    stringstream ss;
    ss << hex << setw(16) << setfill('0') << value;
    return ss.str();
}

unsigned long long fnv1a(const string& text) {
    const unsigned long long offset = 14695981039346656037ULL;
    const unsigned long long prime = 1099511628211ULL;
    unsigned long long hash = offset;

    for (unsigned char ch : text) {
        hash ^= ch;
        hash *= prime;
    }

    return hash;
}

string makeSalt() {
    random_device rd;
    mt19937_64 gen(rd());
    uniform_int_distribution<unsigned long long> dist;
    return toHexNumber(dist(gen));
}

string hashPassword(const string& password, const string& salt) {
    return toHexNumber(fnv1a(salt + ":" + password));
}

bool usernameExists(const string& username) {
    ifstream file(USERS_FILE);
    string savedUser, savedSalt, savedHash;

    while (file >> savedUser >> savedSalt >> savedHash) {
        if (savedUser == username) {
            return true;
        }
    }

    return false;
}

void registerUser() {
    string username, password, confirmPassword;

    cout << "\nEnter new username: ";
    cin >> username;

    if (usernameExists(username)) {
        cout << "Username already exists.\n";
        return;
    }

    cout << "Enter new password: ";
    cin >> password;
    cout << "Confirm password: ";
    cin >> confirmPassword;

    if (password != confirmPassword) {
        cout << "Passwords do not match.\n";
        return;
    }

    string salt = makeSalt();
    string hash = hashPassword(password, salt);

    ofstream file(USERS_FILE, ios::app);
    if (!file) {
        cout << "Unable to open users file.\n";
        return;
    }

    file << username << ' ' << salt << ' ' << hash << '\n';
    cout << "Registration successful.\n";
}

bool login() {
    string username, password;

    cout << "\nUsername: ";
    cin >> username;
    cout << "Password: ";
    cin >> password;

    ifstream file(USERS_FILE);
    if (!file) {
        cout << "No users registered yet.\n";
        return false;
    }

    string savedUser, savedSalt, savedHash;
    while (file >> savedUser >> savedSalt >> savedHash) {
        if (savedUser == username && savedHash == hashPassword(password, savedSalt)) {
            currentUsername = username;
            currentVaultKey = hashPassword(password, savedSalt);
            cout << "Login successful.\n";
            return true;
        }
    }

    cout << "Invalid username or password.\n";
    return false;
}

void logoutUser() {
    currentUsername.clear();
    currentVaultKey.clear();
}

void analyzePassword(string password) {
    bool hasUpper = false;
    bool hasLower = false;
    bool hasDigit = false;
    bool hasSpecial = false;

    for (unsigned char ch : password) {
        if (isupper(ch)) {
            hasUpper = true;
        } else if (islower(ch)) {
            hasLower = true;
        } else if (isdigit(ch)) {
            hasDigit = true;
        } else {
            hasSpecial = true;
        }
    }

    int score = 0;
    if (password.length() >= 8) score++;
    if (password.length() >= 12) score++;
    if (hasUpper) score++;
    if (hasLower) score++;
    if (hasDigit) score++;
    if (hasSpecial) score++;

    cout << "\nStrength: ";
    if (score <= 2) {
        cout << "Weak\n";
    } else if (score <= 4) {
        cout << "Medium\n";
    } else {
        cout << "Strong\n";
    }

    cout << "\nSuggestions:\n";
    bool needsWork = false;

    if (password.length() < 8) {
        cout << "- Increase length to at least 8 characters.\n";
        needsWork = true;
    }
    if (password.length() < 12) {
        cout << "- Use 12 or more characters for better security.\n";
        needsWork = true;
    }
    if (!hasUpper) {
        cout << "- Add an uppercase letter.\n";
        needsWork = true;
    }
    if (!hasLower) {
        cout << "- Add a lowercase letter.\n";
        needsWork = true;
    }
    if (!hasDigit) {
        cout << "- Add a number.\n";
        needsWork = true;
    }
    if (!hasSpecial) {
        cout << "- Add a special character.\n";
        needsWork = true;
    }
    if (!needsWork) {
        cout << "- Password looks strong.\n";
    }
}

bool transformFile(const string& inputName, const string& outputName, const string& key) {
    if (key.empty()) {
        cout << "Key cannot be empty.\n";
        return false;
    }

    ifstream input(inputName, ios::binary);
    if (!input) {
        cout << "Unable to open input file.\n";
        return false;
    }

    vector<char> data((istreambuf_iterator<char>(input)), istreambuf_iterator<char>());
    for (size_t i = 0; i < data.size(); ++i) {
        data[i] = static_cast<char>(data[i] ^ key[i % key.length()]);
    }

    ofstream output(outputName, ios::binary);
    if (!output) {
        cout << "Unable to open output file.\n";
        return false;
    }

    output.write(data.data(), static_cast<streamsize>(data.size()));
    return true;
}

void encryptFile(string filename, string key) {
    string outputName = filename + ".enc";

    if (transformFile(filename, outputName, key)) {
        cout << "Encrypted file created: " << outputName << '\n';
    }
}

void decryptFile(string filename, string key) {
    string outputName;

    if (filename.size() >= 4 && filename.substr(filename.size() - 4) == ".enc") {
        outputName = filename.substr(0, filename.size() - 4) + ".dec";
    } else {
        outputName = filename + ".dec";
    }

    if (transformFile(filename, outputName, key)) {
        cout << "Decrypted file created: " << outputName << '\n';
    }
}

string xorText(const string& text, const string& key) {
    string result = text;
    for (size_t i = 0; i < result.size(); ++i) {
        result[i] = static_cast<char>(result[i] ^ key[i % key.length()]);
    }
    return result;
}

string toHexText(const string& text) {
    stringstream ss;
    ss << hex << setfill('0');

    for (unsigned char ch : text) {
        ss << setw(2) << static_cast<int>(ch);
    }

    return ss.str();
}

int hexValue(char ch) {
    if (ch >= '0' && ch <= '9') return ch - '0';
    if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
    if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
    return 0;
}

string fromHexText(const string& hexText) {
    string result;

    for (size_t i = 0; i + 1 < hexText.length(); i += 2) {
        char ch = static_cast<char>((hexValue(hexText[i]) << 4) + hexValue(hexText[i + 1]));
        result.push_back(ch);
    }

    return result;
}

vector<PasswordEntry> loadEntries() {
    vector<PasswordEntry> entries;
    ifstream file(VAULT_FILE);
    string line;

    while (getline(file, line)) {
        stringstream ss(line);
        PasswordEntry entry;

        if (getline(ss, entry.owner, '\t') &&
            getline(ss, entry.website, '\t') &&
            getline(ss, entry.username, '\t') &&
            getline(ss, entry.encryptedPassword)) {
            entries.push_back(entry);
        }
    }

    return entries;
}

void saveEntries(const vector<PasswordEntry>& entries) {
    ofstream file(VAULT_FILE);

    for (const PasswordEntry& entry : entries) {
        file << entry.owner << '\t'
             << entry.website << '\t'
             << entry.username << '\t'
             << entry.encryptedPassword << '\n';
    }
}

void addPassword() {
    cin.ignore(10000, '\n');

    string website, username, password;

    cout << "\nWebsite: ";
    getline(cin, website);
    cout << "Username: ";
    getline(cin, username);
    cout << "Password: ";
    getline(cin, password);

    PasswordEntry entry;
    entry.owner = currentUsername;
    entry.website = website;
    entry.username = username;
    entry.encryptedPassword = toHexText(xorText(password, currentVaultKey));

    ofstream file(VAULT_FILE, ios::app);
    if (!file) {
        cout << "Unable to open vault file.\n";
        return;
    }

    file << entry.owner << '\t'
         << entry.website << '\t'
         << entry.username << '\t'
         << entry.encryptedPassword << '\n';

    cout << "Password saved.\n";
}

void viewPasswords() {
    vector<PasswordEntry> entries = loadEntries();
    int count = 0;

    cout << "\nSaved Passwords\n";
    cout << "---------------\n";

    for (const PasswordEntry& entry : entries) {
        if (entry.owner == currentUsername) {
            ++count;
            string password = xorText(fromHexText(entry.encryptedPassword), currentVaultKey);
            cout << count << ". " << entry.website
                 << " | " << entry.username
                 << " | " << password << '\n';
        }
    }

    if (count == 0) {
        cout << "No passwords saved.\n";
    }
}

void deletePassword() {
    vector<PasswordEntry> entries = loadEntries();
    vector<int> matchingIndexes;

    cout << "\nYour Password Entries\n";
    cout << "---------------------\n";

    for (size_t i = 0; i < entries.size(); ++i) {
        if (entries[i].owner == currentUsername) {
            matchingIndexes.push_back(static_cast<int>(i));
            cout << matchingIndexes.size() << ". "
                 << entries[i].website << " | "
                 << entries[i].username << '\n';
        }
    }

    if (matchingIndexes.empty()) {
        cout << "No passwords to delete.\n";
        return;
    }

    int choice;
    cout << "Choose entry number to delete: ";
    cin >> choice;

    if (choice < 1 || choice > static_cast<int>(matchingIndexes.size())) {
        cout << "Invalid choice.\n";
        return;
    }

    entries.erase(entries.begin() + matchingIndexes[choice - 1]);
    saveEntries(entries);
    cout << "Password deleted.\n";
}

void passwordManagerMenu() {
    int choice;

    while (true) {
        cout << "\n===== Password Manager =====\n";
        cout << "1. Add Password\n";
        cout << "2. View Passwords\n";
        cout << "3. Delete Password\n";
        cout << "4. Back\n";
        cout << "Choose: ";
        cin >> choice;

        switch (choice) {
            case 1:
                addPassword();
                break;
            case 2:
                viewPasswords();
                break;
            case 3:
                deletePassword();
                break;
            case 4:
                return;
            default:
                cout << "Invalid choice.\n";
        }
    }
}

void dashboard() {
    int choice;

    while (true) {
        cout << "\n============================\n";
        cout << "Welcome, " << currentUsername << '\n';
        cout << "============================\n";
        cout << "1. Password Strength Analyzer\n";
        cout << "2. Encrypt File\n";
        cout << "3. Decrypt File\n";
        cout << "4. Password Manager\n";
        cout << "5. Logout\n";
        cout << "Choose: ";
        cin >> choice;

        if (choice == 1) {
            string password;
            cout << "Password: ";
            cin >> password;
            analyzePassword(password);
        } else if (choice == 2) {
            string filename, key;
            cout << "Filename: ";
            cin >> filename;
            cout << "Encryption key: ";
            cin >> key;
            encryptFile(filename, key);
        } else if (choice == 3) {
            string filename, key;
            cout << "Filename: ";
            cin >> filename;
            cout << "Decryption key: ";
            cin >> key;
            decryptFile(filename, key);
        } else if (choice == 4) {
            passwordManagerMenu();
        } else if (choice == 5) {
            logoutUser();
            cout << "Logged out.\n";
            return;
        } else {
            cout << "Invalid choice.\n";
        }
    }
}

int main() {
    int choice;

    while (true) {
        cout << "\n===========================\n";
        cout << " CyberVault\n";
        cout << "===========================\n";
        cout << "1. Register\n";
        cout << "2. Login\n";
        cout << "3. Exit\n";
        cout << "Choose: ";
        cin >> choice;

        switch (choice) {
            case 1:
                registerUser();
                break;
            case 2:
                if (login()) {
                    dashboard();
                }
                break;
            case 3:
                cout << "Goodbye.\n";
                return 0;
            default:
                cout << "Invalid choice.\n";
        }
    }
}